package Practica1_Colecciones;

import Practica1_Colecciones.Ejercicio1.Ejercicio1;
import Practica1_Colecciones.Ejercicio2.Ejercicio2;
import Practica1_Colecciones.Ejercicio3.Ejercicio3;
import Practica1_Colecciones.Ejercicio4.Ejercicio4;
import Practica1_Colecciones.Ejercicio5.Ejercicio5;

public class Ejercicios {
    public static void main(String[] args) {
        Ejercicio1.main();
        Ejercicio2.main();
        Ejercicio3.main();
        Ejercicio4.main();
        Ejercicio5.main();
    }
}
