package Practica1_Colecciones.Ejercicio1;

/*
Carga de los ficheros de la UD10.Ficheros, el fichero numeros.txt, y realiza la ordenación
descendente y ascendente de los números, para escribirlos a continuación en el mismo
fichero, tras dos separadores con guiones “-------“y escribir “Números ordenados de mayor a
menor: “ y “Números ordenados de menor a mayor: “
 */