package Practica1_Colecciones.Ejercicio2;
/*
Carga el fichero de frases.txt y concaténalas en un mismo texto en un fichero, de forma que
la primera frase sea la más corta, y la última termine siendo la más larga.
 */