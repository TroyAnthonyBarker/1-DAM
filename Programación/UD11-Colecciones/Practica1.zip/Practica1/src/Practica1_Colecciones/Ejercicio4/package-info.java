package Practica1_Colecciones.Ejercicio4;

/*
Implementa un programa que a partir del fichero colores.txt, cree tres HashSet y compare el
1º con el 2º y el 2º con el 3º. Además, deberá convertir el primero a una lista. Posteriormente,
borrará el HashSet que acaba de convertir a lista. Por último, deberá mostrar por pantalla los
elementos que no son iguales entre el 2º y el 3º
 */