package Practica1_Introduccion_a_Java;

public class Ejercicio2 {
    public static void main(String[] args) {
        System.out.println("Buenos días");
    }
}
