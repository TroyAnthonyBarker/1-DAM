package Practica1_Introduccion_a_Java;

public class Ejercicio3 {
    public static void main(String[] args) {
        /**DATOS*/
        int area;
        /**ALGORITMO */
        area= 5 * 5;
        System.out.println("El área de un cuadrado cuyo lado sea igua a 5 es: " + area);
    }
}
