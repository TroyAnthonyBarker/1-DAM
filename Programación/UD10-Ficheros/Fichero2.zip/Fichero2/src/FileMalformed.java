public class FileMalformed extends Exception{
    public FileMalformed(String message) {
        super(message);
    }
}
