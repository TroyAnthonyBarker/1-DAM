public enum Sexo {
    H, M;
}
